package com.gamingroom;


// base class entity
public class Entity {
	
	protected long id;
	protected String name;
	
	// constructor to prevent empty instances
	protected Entity() {
	}

	//public constructor 
	public Entity(long id, String name) {
		this();
		this.id = id;
		this.name = name;
	}
	
	//returns object id
	public long getId() {
		return id;
	}
	
	
	// returns object name
	public String getName() {
		return name;
	}
	
	// prints object info
	public String toString() {
		return "Entity [id=" + id + ", name=" + name + "]";
	}

}
