package com.gamingroom;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * A simple class to hold information about a game
 * 
 * <p>
 * Notice the overloaded constructor that requires
 * an id and name to be passed when creating.
 * Also note that no mutators (setters) defined so
 * these values cannot be changed once a game is
 * created.
 * </p>
 * 
 * @author coce@snhu.edu
 *
 */
public class Game extends Entity{
	
	
	//list of active teams
	private static List<Team> teams = new ArrayList<Team>();
	
	
	//Hide the default constructor to prevent creating empty instances.
	private Game() {
	}
	

	//Constructor with an identifier and name
	public Game(long id, String name) {
		this();
		this.id = id;
		this.name = name;
	}


	//adds a team to team list. If the team already exists it is not added.
	public Team addTeam(String name) {
		
		Team Team = null; // local team instance
		
		Iterator<Team> iterator = teams.iterator(); // creates iterator for team object
		
		//loops over team list and returns existing instance if there is one
		while(iterator.hasNext()) {
			Team tempTeam = iterator.next();
			if(tempTeam.getName().equals(name)) { // if team exists
				Team = tempTeam;
				return tempTeam; // returns existing instance
			}
		}
		
		// if the team is not found, make a new team instance and add to list of teams
		if (Team == null) {
			GameService service = GameService.getInstance(); // gets game service instance for id
			Team = new Team(service.getNextTeamId(), name);
			teams.add(Team);
		}
		
		return Team; // returns new or existing team
	}
	
	
	//prints the list of teams for a game. Used for testing.
	public String getTeams() {
		return teams.toString();
	}

	
	@Override
	public String toString() {
		
		return "Game [id=" + id + ", name=" + name + "]";
	}

}
