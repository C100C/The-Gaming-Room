package com.gamingroom;

import java.util.ArrayList;
import java.util.List;
import java.util.Iterator;

/**
 * A singleton service for the game engine
 * 
 * @author coce@snhu.edu
 */
public class GameService {

	//A list of the active games
	private static List<Game> games = new ArrayList<Game>();

	private static long nextGameId = 1; //Holds the next game identifier
	
	private static long nextPlayerId = 1; //Holds the next player id 
	
	private static long nextTeamId = 1; //Holds the next team id
	
	
	//Singleton
	//Creates a single instance of game service. 
	 private static GameService instance = null;
	
	// private constructor to prevent instantiation
	private GameService() {}
	
	// public method that allows access to a single instance. Will only return the one object
	public static GameService getInstance() {
	    if (instance == null) {
	        instance = new GameService();
	    }
		return instance;
	}
	


	/**
	 * Construct a new game instance
	 * 
	 * @param name the unique name of the game
	 * @return the game instance (new or existing)
	 */
	public Game addGame(String name) {

		// a local game instance
		Game game = null;
		
		Iterator<Game> iterator = games.iterator(); // creates iterator for game object
		
		//loops over game list
		while(iterator.hasNext()) {
			Game iteratorGame = iterator.next(); // gets next item
			if(iteratorGame.getName().equals(name)) { // if the game exists
				game = iteratorGame;
				return game; // returns existing instance
			}
		}
		// if not found, make a new game instance and add to list of games
		if (game == null) {
			game = new Game(nextGameId++, name);
			games.add(game);
		}
		// return the new/existing game instance to the caller
		return game;
	}

	
	
	/**
	 * Returns the game instance at the specified index.
	 * <p>
	 * Scope is package/local for testing purposes.
	 * </p>
	 * @param index index position in the list to return
	 * @return requested game instance
	 */
	Game getGame(int index) {
		return games.get(index);
	}
	
	
	
	/**
	 * Returns the game instance with the specified id.
	 * 
	 * @param id unique identifier of game to search for
	 * @return requested game instance
	 */
	public Game getGame(long id) {

		// a local game instance
		Game game = null;
	
		// creates iterator for the game object
		Iterator<Game> iterator = games.iterator();
		
		//loops over game list
		while(iterator.hasNext()) {
			Game iteratorGame = iterator.next();
			if(iteratorGame.getId() == id) { // if the game exists
				game = iteratorGame;
			}
		}
		return game; // if game doesn't exists null will be returned
	}

	
	
	/**
	 * Returns the game instance with the specified name.
	 * 
	 * @param name unique name of game to search for
	 * @return requested game instance
	 */
	public Game getGame(String name) {

		// a local game instance
		Game game = null;
		
		// creates iterator for the game object
		Iterator<Game> iterator = games.iterator();
		
		//loops over game list
		while(iterator.hasNext()) {
			Game iteratorGame = iterator.next();
			if(iteratorGame.getName().equals(name)) { // if game exists
				game = iteratorGame;
			}
		}
		return game; // if game doesn't exists null will be returned
	}
	

	
	/**
	 * @return the number of games currently active
	 */
	public int getGameCount() {
		return games.size();
	}
	
	
	//returns next player id and adds one for next
	public long getNextPlayerId() {
		return nextPlayerId++;
		
	}
	
	
	//returns next team id and adds one for next
	public long getNextTeamId() {
		return nextTeamId++;
	}
	
}

/*
 * Explanation of iterator design pattern
 * 
 * The iterator design pattern is used to access elements of an object without needing to know its underlying representation.
 * It is also used to protect the internal structure of the object.
 * 
 * In this program we used it three times in the getGame(name), getGame(ID) and addGame(name) methods.
 * Instead of fully implementing the design pattern we used Java's built in iterator.
 * 
 * We looped or iterated over the list of games to ensure that 2 games are not in play at the same time. 
 * Or if a game is in the list it cannot be added again with the same Name and ID.
 * 
 * 
 * 
 * 
 * Explanation of singleton design pattern
 * 
 * The singleton pattern is used to ensure that a class only has one instance and provides global access.
 * In this program I made a static instance of the GamesService.
 * Then the constructor is made private to prevent instantiation or creation of another.
 * The getInstance function is used to return instance or the one and only GameService Object. 
 * It is needed too access the class.
 * 
 * */
