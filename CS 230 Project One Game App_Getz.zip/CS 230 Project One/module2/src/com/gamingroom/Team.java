package com.gamingroom;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * A simple class to hold information about a team
 * <p>
 * Notice the overloaded constructor that requires
 * an id and name to be passed when creating.
 * Also note that no mutators (setters) defined so
 * these values cannot be changed once a team is
 * created.
 * </p>
 * @author coce@snhu.edu
 *
 */
public class Team extends Entity{

	//list of active players
	private static List<Player> players = new ArrayList<Player>();
	
	
	//Constructor with an identifier and name
	public Team(long id, String name) {
		this.id = id;
		this.name = name;
	}

	
	// adds a player to players list. If player already exists it is not added.
	public Player addPlayer() {
		
		Player Player = null; // local player instance
		
		Iterator<Player> iterator = players.iterator(); // creates iterator for Player object
		
		//loops over players list and returns existing instance if there is one
		while(iterator.hasNext()) {
			Player tempPlayer = iterator.next();
			if(tempPlayer.getName().equals(name)) { // if Player already exists
				Player = tempPlayer;
				return Player; // returns existing instance of player
			}
		}
		
		// if the player is not found, make a new player instance and add to list of players
		if (Player == null) {
			GameService service = GameService.getInstance(); // gets game service instance for id
			Player = new Player(service.getNextPlayerId(), name);
			players.add(Player); // adds player to players list
		}
		
		return Player; // returns new or existing team
	}


	@Override
	public String toString() {
		return "Team [id=" + id + ", name=" + name + "]";
	}
}
