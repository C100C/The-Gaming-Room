package com.gamingroom;

/**
 * Application start-up program
 * 
 * @author coce@snhu.edu
 */
public class ProgramDriver {
	
	/**
	 * The one-and-only main() method
	 * 
	 * @param args command line arguments
	 */
	public static void main(String[] args) {
		
		//obtains reference to the singleton instance
		GameService service = GameService.getInstance();
		
		System.out.println("\nAbout to test initializing game data...");
		
		// initialize with some game data
		Game game1 = service.addGame("Game #1");
		System.out.println(game1);
		Game game2 = service.addGame("Game #2");
		System.out.println(game2);
		Game game3 = service.addGame("Game #3");
		System.out.println(game3 + "\n");
		
		System.out.println("Testing Methods");
		
		System.out.println("getGame(String) test: " + service.getGame("Game #2"));
		
		// adds 4 teams to game3
		game3.addTeam("Ctrl+Alt+Defeat");
		game3.addTeam("Ctrl+Alt+Defeat");
		game3.addTeam("Apples");
		game3.addTeam("Apples");
		game3.addTeam("Crushers");
		game3.addTeam("Eric");
		
		System.out.println("Game3 Teams: = " + game3.getTeams()); // prints the list of teams. Note 2nd Apples or Ctrl+Alt+Defeat is not added

		System.out.println("toString Test: " + game3.toString()); // test toString method
		
		// use another class to prove there is only one instance
		SingletonTester tester = new SingletonTester();
		tester.testSingleton();
	}
}